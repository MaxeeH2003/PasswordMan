package com.example.career;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CourseViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_view);
    }
}