package com.example.career;


import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CourseListFragment extends Fragment implements CourseAdapter.OnItemClickListener {
    private RecyclerView recyclerView;
    private CourseAdapter courseAdapter;

    public CourseListFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_course_list, container, false);

        // Assuming you have a list of courses
        List<Course> courseList = getCourseList();

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        courseAdapter = new CourseAdapter(courseList, this);
        recyclerView.setAdapter(courseAdapter);

        return view;
    }

    private List<Course> getCourseList() {
        // Add sample courses
        List<Course> courses = new ArrayList<>();
        courses.add(new Course("Course 1", "Description 1"));
        courses.add(new Course("Course 2", "Description 2"));
        // Add more courses as needed
        return courses;
    }

    @Override
    public void onItemClick(Course course) {
        // Handle the "View" button click for the selected course
        Intent intent = new Intent(getActivity(), CourseViewActivity.class);
        startActivity(intent);
        Toast.makeText(getActivity(), "Viewing: " + course.getName(), Toast.LENGTH_SHORT).show();
        // Add your logic to navigate to the course details page or perform any action
    }
}
